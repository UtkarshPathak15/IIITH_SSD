js file is named script.js
css file is style.css
